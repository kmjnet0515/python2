'''
작성일 : 2023년 9월 13일
작성자 : 컴퓨터공학과 202395006 김민재
설명 : 터틀 사용하기
'''
import turtle as t #터틀 모듈을 사용하기 위한 준비 # turtle 클래스 객체를 t로 생성. (별명)
t.color('red') # 색깔 지정하기
t.shape('turtle')   #모양 지정하기
t.bgcolor('black')  #배경색 지정하기
t.speed(5)  #속도 지정하기
#선그리기
for p in range(10):
    for k in range(6):
        for q in range(3):
            t.forward(30)
            t.left(120)
        if p % 2 == 0:
            t.left(60)
        else:
            t.left(120)
            t.forward((p//2+1)*30)
            t.right(120)
    t.forward(30*(p+1))

for num in range(3,100):
    for k in range(5):
        for i in range(num):
            t.forward(10)
            t.left(180-(180*(num-2)/num))
        t.left(72)
    print("{}각형".format(num))
t.mainloop()