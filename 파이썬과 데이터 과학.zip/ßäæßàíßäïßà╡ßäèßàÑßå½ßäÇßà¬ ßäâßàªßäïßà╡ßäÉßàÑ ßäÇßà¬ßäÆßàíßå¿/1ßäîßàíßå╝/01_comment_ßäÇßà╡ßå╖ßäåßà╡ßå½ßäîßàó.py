'''
작성일 : 2023년 9월 13일
작성자 : 컴퓨터공학과 202395006 김민재
설명 : 주석과 출력 함수 사용하기.
'''
major = "컴퓨터공학과"
id = 202395006
name = '김민재'
print("학과 : ", major)
print("학번 : {}".format(id))

#안녕하세요. 저는 00학과 00학번 00입니다.
print("안녕하세요. 저는 {}학과 {}학번 {}입니다.".format(major[:-2], id, name))
print("파이썬" * 10)

num1 = 10
num2 = '20'
#int()함수는 int형으로 변환해줌
print(num1 + int(num2))